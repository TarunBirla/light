<?php

use App\Http\Controllers\Admin\BookingController;
use App\Http\Controllers\Admin\ItemController;
use App\Http\Controllers\Front\BookingController as UserBookingController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\BannerController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\BrandController;
use App\Http\Controllers\Admin\PortfolioController;
use App\Http\Controllers\Admin\TelevisionController;
use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\DashboardController;


use App\Http\Controllers\Admin\GeneratorBannerController;

use App\Http\Controllers\Front\HomeController;
use App\Http\Controllers\Front\AuthController as FrontAuthController;

use App\Http\Controllers\Front\CategoryController as FrontCategoryController;
use App\Http\Controllers\Front\ItemController as FrontItemController;
use App\Http\Controllers\Front\EquipmentRequestController as FrontEquipmentRequestController;
use App\Http\Controllers\Admin\EquipmentRequestController as AdminEquipmentRequestController;
use App\Http\Controllers\Admin\AuctionProductController;
use App\Http\Controllers\Admin\AuctionRequestController;
use App\Http\Controllers\Admin\UserController as AdminUserController;
use App\Http\Controllers\Front\AuctionController;

use App\Http\Controllers\Front\SitemapController;

Route::get('/sitemap.xml', [SitemapController::class, 'index'])->name('sitemap');
Route::get('/llm.txt', function () {
    return response()->file(public_path('llm.txt'), ['Content-Type' => 'text/plain; charset=utf-8']);
});
Route::get('/llms.txt', function () {
    return response()->file(public_path('llms.txt'), ['Content-Type' => 'text/plain; charset=utf-8']);
});

Route::get('/open-account', [\App\Http\Controllers\Front\AccountOpeningController::class, 'create'])->name('front.account-opening');
Route::post('/open-account', [\App\Http\Controllers\Front\AccountOpeningController::class, 'store'])->name('front.account-opening.store');

Route::get('/equipment-request', [FrontEquipmentRequestController::class, 'index'])->name('equipment-request.index');
Route::post('/equipment-request', [FrontEquipmentRequestController::class, 'store'])->name('equipment-request.store');

Route::get('/equipment-requestnew', [FrontEquipmentRequestController::class, 'indexNew'])->name('equipment-requestnew.index');
Route::post('/equipment-requestnew', [FrontEquipmentRequestController::class, 'storeNew'])->name('equipment-requestnew.store');

Route::get('/auctions', [AuctionController::class, 'index'])->name('front.auctions.index');
Route::get('/auction/{id}', [AuctionController::class, 'show'])->name('front.auctions.show');
Route::post('/auction-request', [AuctionController::class, 'storeRequest'])->name('front.auctions.store-request');

Route::get('/blogs', [\App\Http\Controllers\Front\BlogController::class, 'index'])->name('front.blogs.index');
Route::get('/blog/{slug}', [\App\Http\Controllers\Front\BlogController::class, 'show'])->name('front.blogs.show');




Route::post(
    '/guest-request',
    [HomeController::class,'guestRequest']
);

Route::get(
    '/categories',
    [FrontCategoryController::class,'index']
);
Route::get('/about', function () {
    return view('front.about');
});
Route::get('/brand', function () {
    return view('front.brand');
});
Route::get('/television', function () {
    return view('front.television');
});
Route::get('/portfolio', function () {
    return view('front.portfolio');
});
Route::get('/terms', function () {
    return view('front.terms');
});
Route::get(
    '/category/{id}',
    [FrontCategoryController::class,'show']
);

Route::get(
    '/items',
    [FrontItemController::class,'index']
);
Route::get('/', [HomeController::class, 'index']);

Route::get(
    '/item/{id}',
    [HomeController::class, 'itemDetail']
);

Route::middleware('auth')->group(function () {

    Route::post(
        '/add-to-cart',
        [UserBookingController::class, 'addToCart']
    );
Route::get(
    '/cart/increase/{id}',
    [UserBookingController::class,'increaseQty']
)->name('cart.increase');

Route::get(
    '/cart/decrease/{id}',
    [UserBookingController::class,'decreaseQty']
)->name('cart.decrease');
    Route::get(
        '/cart',
        [UserBookingController::class, 'cart']
    );

    Route::get(
        '/checkout',
        [UserBookingController::class, 'checkoutPage']
    );

    Route::post(
        '/place-order',
        [UserBookingController::class, 'placeOrder']
    );

    Route::get(
        '/my-bookings',
        [UserBookingController::class, 'myBookings']
    );

    Route::get(
        '/booking/{id}',
        [UserBookingController::class, 'bookingDetail']
    );
    Route::get(
        '/cart/remove/{id}',
        [UserBookingController::class, 'removeCart']
    )->name('cart.remove');
});

Route::get('/login', [FrontAuthController::class, 'login'])->name('login');
Route::post('/login', [FrontAuthController::class, 'loginSubmit']);

Route::get('/register', [FrontAuthController::class, 'register'])->name('register');
Route::post('/register', [FrontAuthController::class, 'registerSubmit']);

Route::get('/forgot-password', [FrontAuthController::class, 'forgotPassword'])->name('password.request');
Route::post('/forgot-password', [FrontAuthController::class, 'forgotPasswordSubmit'])->name('password.email');

Route::get('/reset-password', [FrontAuthController::class, 'resetPassword'])->name('password.reset');
Route::post('/reset-password', [FrontAuthController::class, 'resetPasswordSubmit'])->name('password.update');

Route::get('/logout', [FrontAuthController::class, 'logout'])->name('logout');

Route::get('/profile', [FrontAuthController::class, 'profile'])
    ->name('profile')
    ->middleware('auth');
Route::post('/profile', [FrontAuthController::class, 'profileUpdate'])
    ->name('front.profile.update')
    ->middleware('auth');

Route::get(
    '/admin/login',
    [AuthController::class, 'login']
);

Route::post(
    '/admin/login',
    [AuthController::class, 'loginSubmit']
);



Route::get('/sync-database', [\App\Http\Controllers\Admin\MigrationHelperController::class, 'syncDatabase'])->name('sync-database');
Route::get('/run-all-migrations', [\App\Http\Controllers\Admin\MigrationHelperController::class, 'syncDatabase'])->name('run-all-migrations');
Route::get('/run-auction-migrations', [\App\Http\Controllers\Admin\MigrationHelperController::class, 'runMigrations'])->name('run-auction-migrations');
Route::get('/run-analytics-migrations', [\App\Http\Controllers\Admin\MigrationHelperController::class, 'runMigrations'])->name('run-analytics-migrations');
Route::get('/run-account-migrations', [\App\Http\Controllers\Admin\MigrationHelperController::class, 'runMigrations'])->name('run-account-migrations');
Route::get('/run-blog-migrations', [\App\Http\Controllers\Admin\MigrationHelperController::class, 'runMigrations'])->name('run-blog-migrations');
Route::get('/clear-cache', [\App\Http\Controllers\Admin\MigrationHelperController::class, 'clearCache'])->name('clear-cache');

Route::middleware(['auth', 'admin'])
    ->prefix('admin')
    ->group(function () {

    Route::get('/analytics', [\App\Http\Controllers\Admin\AnalyticsController::class, 'index'])->name('admin.analytics.index');
    Route::get('/analytics/visitor-journey/{id}', [\App\Http\Controllers\Admin\AnalyticsController::class, 'visitorJourney'])->name('admin.analytics.journey');

    // Account Applications
    Route::get('/account-applications', [\App\Http\Controllers\Admin\AccountApplicationController::class, 'index'])->name('admin.account-applications.index');
    Route::get('/account-applications/{id}', [\App\Http\Controllers\Admin\AccountApplicationController::class, 'show'])->name('admin.account-applications.show');
    Route::patch('/account-applications/{id}/status', [\App\Http\Controllers\Admin\AccountApplicationController::class, 'updateStatus'])->name('admin.account-applications.status');
    Route::delete('/account-applications/{id}', [\App\Http\Controllers\Admin\AccountApplicationController::class, 'destroy'])->name('admin.account-applications.destroy');

    // Blogs Management
    Route::resource('blogs', \App\Http\Controllers\Admin\BlogController::class)->names('admin.blogs');
    Route::patch('/blogs/{id}/status', [\App\Http\Controllers\Admin\BlogController::class, 'updateStatus'])->name('admin.blogs.status');

    Route::resource('steps', \App\Http\Controllers\Admin\AuctionStepController::class)->names('admin.steps');
    Route::resource('auction-faqs', \App\Http\Controllers\Admin\AuctionFaqController::class)->names('admin.auction-faqs');

    Route::resource(
    'brands',
    BrandController::class
);
Route::resource(
    'generator-banners',
    GeneratorBannerController::class
);

Route::resource(
    'portfolios',
    PortfolioController::class
);

Route::resource(
    'televisions',
    TelevisionController::class
);
Route::delete(
    '/category-image/{id}',
    [CategoryController::class,'deleteImage']
)->name('category.image.delete');

    Route::get(
        '/bookings',
        [BookingController::class,'index']
    )->name('admin.bookings');

    Route::get(
        '/users',
        [BookingController::class,'users']
    )->name('admin.users');
    Route::get(
    '/admin/booking/{id}',
    [BookingController::class,'show']
)->name('admin.booking.show');
Route::get(
'/admin/booking/{id}/approve',
[BookingController::class,'approve']
)->name('admin.booking.approve');

Route::get(
'/admin/booking/{id}/reject',
[BookingController::class,'reject']
)->name('admin.booking.reject');

Route::get(
'/admin/booking/{id}/complete',
[BookingController::class,'complete']
)->name('admin.booking.complete');

        Route::get(
            '/dashboard',
            [DashboardController::class, 'index']
        );

        Route::resource(
            'banner',
            BannerController::class
        );

      Route::get(
    '/requests',
    [BookingController::class,'requests']
)->name('admin.requests');
Route::delete(
    '/requests/{id}',
    [BookingController::class,'deleteRequest']
)->name('admin.requests.delete');

        Route::resource(
            'category',
            CategoryController::class
        );

        Route::resource(
            'items',
            ItemController::class
        );

        Route::get('/equipment-requests', [AdminEquipmentRequestController::class, 'index'])->name('admin.equipment-requests.index');
        Route::get('/equipment-requests/{id}', [AdminEquipmentRequestController::class, 'show'])->name('admin.equipment-requests.show');
        Route::delete('/equipment-requests/{id}', [AdminEquipmentRequestController::class, 'destroy'])->name('admin.equipment-requests.destroy');

        Route::resource('auction-products', AuctionProductController::class);
        Route::get('/auction-requests', [AuctionRequestController::class, 'index'])->name('auction-requests.index');
        Route::patch('/auction-requests/{id}/status', [AuctionRequestController::class, 'updateStatus'])->name('auction-requests.status');
        Route::delete('/auction-requests/{id}', [AuctionRequestController::class, 'destroy'])->name('auction-requests.destroy');

        Route::get('/all-users', [AdminUserController::class, 'index'])->name('admin.all-users.index');
        Route::patch('/all-users/{id}/status', [AdminUserController::class, 'updateStatus'])->name('admin.all-users.status');
        Route::delete('/all-users/{id}', [AdminUserController::class, 'destroy'])->name('admin.all-users.destroy');


        Route::get(
            'logout',
            [AuthController::class, 'logout']
        );

    });




