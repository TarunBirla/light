<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    public function login()
    {
        if (Auth::check()) {
            return redirect('/');
        }
        return view('front.auth.login');
    }

    public function register()
    {
        if (Auth::check()) {
            return redirect('/');
        }
        return view('front.auth.register');
    }

    public function registerSubmit(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name'  => 'required|string|max:255',
            'email'      => 'required|email|max:255|unique:users,email',
            'phone'      => 'required|string|max:50',
            'address'    => 'required|string|max:500',
            'password'   => 'required|string|min:6',
            'terms'      => 'required|accepted',
        ], [
            'first_name.required' => 'First name is required.',
            'last_name.required'  => 'Last name is required.',
            'email.required'       => 'Email address is required.',
            'email.unique'         => 'This email address is already registered.',
            'phone.required'       => 'Phone number is required.',
            'address.required'     => 'Address is required.',
            'password.required'    => 'Password is required.',
            'password.min'         => 'Password must be at least 6 characters.',
            'terms.accepted'       => 'You must agree to the Terms and Conditions.',
        ]);

        $user = User::create([
            'first_name' => $request->first_name,
            'last_name'  => $request->last_name,
            'name'       => trim($request->first_name . ' ' . $request->last_name),
            'email'      => $request->email,
            'phone'      => $request->phone,
            'mobile'     => $request->phone,
            'address'    => $request->address,
            'password'   => Hash::make($request->password),
            'role'       => 'user',
            'status'     => 'active',
        ]);

        Auth::login($user);

        return redirect()->intended('/auctions')->with('success', 'Account registered successfully! Welcome to Light As Air.');
    }

    public function loginSubmit(Request $request)
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required|string',
        ]);

        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            $user = Auth::user();

            if ($user->status === 'suspended') {
                Auth::logout();
                return back()->with('error', 'Your account has been suspended by Admin. Please contact support.');
            }

            if ($user->status === 'inactive') {
                Auth::logout();
                return back()->with('error', 'Your account is currently inactive. Please contact support.');
            }

            return redirect()->intended('/auctions')->with('success', 'Logged in successfully!');
        }

        return back()->with('error', 'Invalid email or password credentials.')->withInput($request->only('email'));
    }

    public function forgotPassword()
    {
        if (Auth::check()) {
            return redirect('/');
        }
        return view('front.auth.forgot-password');
    }

    public function forgotPasswordSubmit(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:users,email',
        ], [
            'email.required' => 'Email address is required.',
            'email.exists'   => 'We could not find an account registered with this email address.',
        ]);

        $token = Str::random(64);

        // Auto-create table if missing on live server
        try {
            if (!Schema::hasTable('password_reset_tokens')) {
                Schema::create('password_reset_tokens', function ($table) {
                    $table->string('email')->primary();
                    $table->string('token');
                    $table->timestamp('created_at')->nullable();
                });
            }

            DB::table('password_reset_tokens')->updateOrInsert(
                ['email' => $request->email],
                [
                    'email'      => $request->email,
                    'token'      => $token,
                    'created_at' => now(),
                ]
            );
        } catch (\Exception $e) {
            // Fallback: save reset token in user's remember_token field
            User::where('email', $request->email)->update(['remember_token' => $token]);
        }

        return redirect()->route('password.reset', ['token' => $token, 'email' => $request->email])
            ->with('success', 'Account verified! Please enter your new password below to reset.');
    }

    public function resetPassword(Request $request)
    {
        if (Auth::check()) {
            return redirect('/');
        }
        $email = $request->get('email');
        $token = $request->get('token');
        return view('front.auth.reset-password', compact('email', 'token'));
    }

    public function resetPasswordSubmit(Request $request)
    {
        $request->validate([
            'email'                 => 'required|email|exists:users,email',
            'token'                 => 'required|string',
            'password'              => 'required|string|min:6|confirmed',
        ], [
            'email.required'        => 'Email address is required.',
            'email.exists'          => 'Invalid email address.',
            'password.required'     => 'New password is required.',
            'password.min'          => 'New password must be at least 6 characters.',
            'password.confirmed'    => 'Password confirmation does not match.',
        ]);

        $validToken = false;

        try {
            if (Schema::hasTable('password_reset_tokens')) {
                $record = DB::table('password_reset_tokens')
                    ->where('email', $request->email)
                    ->where('token', $request->token)
                    ->first();
                if ($record) {
                    $validToken = true;
                }
            }
        } catch (\Exception $e) {
            // ignore
        }

        if (!$validToken) {
            $userCheck = User::where('email', $request->email)
                ->where('remember_token', $request->token)
                ->first();
            if ($userCheck) {
                $validToken = true;
            }
        }

        if (!$validToken) {
            return back()->with('error', 'Invalid or expired password reset token. Please request a new one.');
        }

        $user = User::where('email', $request->email)->first();
        if ($user) {
            $user->update([
                'password'       => Hash::make($request->password),
                'remember_token' => null,
            ]);

            try {
                if (Schema::hasTable('password_reset_tokens')) {
                    DB::table('password_reset_tokens')->where('email', $request->email)->delete();
                }
            } catch (\Exception $e) {
                // ignore
            }

            return redirect('/login')->with('success', 'Password reset successfully! You can now login with your new password.');
        }

        return back()->with('error', 'Unable to reset password. Please try again.');
    }

    public function profile()
    {
        $user = Auth::user();
        
        $myBids = \App\Models\AuctionRequest::with('auctionProduct')
            ->where(function($q) use ($user) {
                $q->where('email', $user->email);
                if (!empty($user->phone)) {
                    $q->orWhere('phone', $user->phone);
                }
                if (!empty($user->main_phone)) {
                    $q->orWhere('phone', $user->main_phone);
                }
            })
            ->latest()
            ->get();

        $winningBids = \App\Models\AuctionRequest::with('auctionProduct')
            ->where(function($q) use ($user) {
                $q->where('email', $user->email);
                if (!empty($user->phone)) {
                    $q->orWhere('phone', $user->phone);
                }
                if (!empty($user->main_phone)) {
                    $q->orWhere('phone', $user->main_phone);
                }
            })
            ->whereIn('status', ['approved', 'completed', 'won', 'accepted'])
            ->latest()
            ->get();

        return view('front.auth.profile', compact('user', 'myBids', 'winningBids'));
    }

    public function profileUpdate(Request $request)
    {
        $user = Auth::user();

        $request->validate([
            'first_name'    => 'required|string|max:255',
            'last_name'     => 'required|string|max:255',
            'company_name'  => 'nullable|string|max:255',
            'job_title'     => 'nullable|string|max:255',
            'address_line1' => 'required|string|max:255',
            'address_line2' => 'nullable|string|max:255',
            'city'          => 'required|string|max:255',
            'county'        => 'nullable|string|max:255',
            'postcode'      => 'required|string|max:100',
            'country'       => 'required|string|max:255',
            'main_phone'    => 'required|string|max:100',
            'mobile_number' => 'nullable|string|max:100',
        ], [
            'first_name.required'    => 'First name is required.',
            'last_name.required'     => 'Last name is required.',
            'address_line1.required' => 'Address Line 1 is required.',
            'city.required'          => 'City is required.',
            'postcode.required'      => 'Postcode / Zip code is required.',
            'country.required'       => 'Country is required.',
            'main_phone.required'    => 'Main phone number is required.',
        ]);

        $combinedAddress = $request->address_line1;
        if (!empty($request->address_line2)) {
            $combinedAddress .= ', ' . $request->address_line2;
        }
        $combinedAddress .= ', ' . $request->city . ', ' . $request->country . ' ' . $request->postcode;

        $user->update([
            'first_name'    => $request->first_name,
            'last_name'     => $request->last_name,
            'name'          => trim($request->first_name . ' ' . $request->last_name),
            'company_name'  => $request->company_name,
            'job_title'     => $request->job_title,
            'address_line1' => $request->address_line1,
            'address_line2' => $request->address_line2,
            'city'          => $request->city,
            'county'        => $request->county,
            'postcode'      => $request->postcode,
            'country'       => $request->country,
            'main_phone'    => $request->main_phone,
            'mobile_number' => $request->mobile_number,
            'phone'         => $request->main_phone ?: $request->mobile_number,
            'address'       => $combinedAddress,
        ]);

        return back()->with('success', 'Profile details updated successfully!');
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/login')->with('success', 'Logged out successfully.');
    }
}